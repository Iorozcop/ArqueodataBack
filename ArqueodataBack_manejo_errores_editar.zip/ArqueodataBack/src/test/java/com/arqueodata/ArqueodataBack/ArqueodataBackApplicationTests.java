package com.arqueodata.ArqueodataBack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArqueodataBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
